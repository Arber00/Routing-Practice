import React from "react";
import Home from "./components/Home";
import Number from "./components/Number";
import Word from "./components/Word";

import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

    
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/home" element={<Home />} />
        <Route path="/word/:word" element={<Word />}/>
        <Route path="/number/:nr" element={<Number />}/>
        <Route path="/word/:word/:color/:backgroundColor" element={<Word />}/>
      </Routes>
    </BrowserRouter>
  );
}
    
export default App;