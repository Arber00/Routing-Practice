import { useParams } from "react-router";

const Number = (props) => {
  const { nr } = useParams();

  return (
    <div>{isNaN(nr) ? <p>Not a number!</p> : <h1>The number is: {nr}</h1>}</div>
  );
};

export default Number;
