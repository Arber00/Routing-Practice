import { useParams } from "react-router";

const Word = (props) => {
    const { word, color, backgroundColor } = useParams();

    return (
        <h1 style={{ backgroundColor: backgroundColor, color: color }}>
            The word is {word}!
        </h1>
    );
};

export default Word;
